import React from 'react';
import "../static/style.css";

const Header = (props) => {
    return(
            <h1 className="site-header">Coding Dojo Pet Shelter</h1>
    );
}
export default Header;